document.addEventListener("DOMContentLoaded", function () {

    const btn = document.getElementById("Btn");
    const quizContainer = document.querySelector(".quiz-container");

    function normalize(text) {
        return (text || "")
            .toLowerCase()
            .replace(/[^a-z0-9\s]/g, "")
            .replace(/\s+/g, " ")
            .trim();
    }

    btn.addEventListener("click", function () {

        const textareas = document.querySelectorAll("textarea");
        let totalScore = 0;

        textareas.forEach((textarea) => {

            const feedback = textarea.nextElementSibling;
            if (!feedback || !feedback.classList.contains("result-feedback")) return;

            const correct = normalize(textarea.dataset.answer);
            const user = normalize(textarea.value);

let score = 0;

if (user === correct) {
    score = 5;
} else {
    score = 0;
}

totalScore += score;

feedback.innerHTML = `
    <b>Score:</b> ${score}/5
    <br>
    <b>Correct Answer:</b> ${textarea.dataset.answer}
`;

const preview = document.createElement("div");
preview.className = "highlight-box";

if (score === 5) {
    preview.classList.add("correct");
} else {
    preview.classList.add("wrong");
}

preview.innerHTML = textarea.value || "(No answer)";

textarea.style.display = "none";
textarea.parentNode.insertBefore(preview, feedback);

            textarea.style.display = "none";
            textarea.parentNode.insertBefore(preview, feedback);
        });

        let resultBox = document.getElementById("totalResult");

        if (!resultBox) {
            resultBox = document.createElement("div");
            resultBox.id = "totalResult";
            resultBox.style.marginTop = "20px";
            resultBox.style.fontSize = "22px";
            resultBox.style.fontWeight = "bold";
            quizContainer.appendChild(resultBox);
        }

        resultBox.innerHTML = `TOTAL SCORE: ${totalScore}`;
    });

});